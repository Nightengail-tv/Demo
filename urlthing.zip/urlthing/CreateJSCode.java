import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;

public class CreateJSCode {
    public static ArrayList<String> readFile(String dir) {
        ArrayList<String> arr = new ArrayList<String>();

        try {
            File file = new File(dir);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String str;

            while ((str = br.readLine()) != null) {
                arr.add(str);
            }
        } catch(IOException e) {
            System.out.println("This program messed up");
        }

        return arr;
    }

    public static void writeFile(String dir) {
        try {
            ArrayList<String> lines = readFile("urls.txt");

            FileWriter write = new FileWriter(dir, false);
            PrintWriter print = new PrintWriter(write);

            print.write("function makeIFrame(src) {\n"+
                "   var frame = document.createElement(\"iframe\");\n"+
                "   frame.setAttribute(\"src\", src);\n"+
                "   frame.style.width = \"640px\";\n"+
                "   frame.style.height = \"480px\";\n"+
                "   document.body.appendChild(frame);\n"+
                "}\n");

            for (String line : lines) {
                print.write("\nmakeIFrame(\"" + line + "\")");
            }

            print.close();
        } catch(IOException e) {
            System.out.println("This program messed up");
        }
    }

    public static void main(String[] args) {
        writeFile("js/main.js");
    }
}